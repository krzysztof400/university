279757, Krzysztof Zając
sposób kompilacji:

``` bash
make
```
w bash'u

tworzy plik experimental, który przyjmuje argumenty tak jak w zaleceniu do zadania.