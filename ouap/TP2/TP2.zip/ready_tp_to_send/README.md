# ADALINE Neural Network Analysis

## 1. Theoretical/Mathematical Solution for Weights


## 2. Weights of Second Order ADALINE Neural Network

Look point 4.

## 3. Weights for Third Order ADALINE Neural Network

Look point 4.

## 4. Implementation in Python

Implementation of ADALINE neural network of first, second and third order. Is found in two python files. ANC_keras.py containes implementation in keras. ANC_myNN.py containes my own implementation of ADALINE neural network.

## 5. Analytical Solution and Simulation

Look point 4

## 6. Analysis and Conclusion

By comparing the weights and performance of second and third order ADALINE networks, we can conclude the effectiveness of additional inputs. The simulation results should show improved performance with higher order networks, given sufficient training data and appropriate learning rates. Outputs given by programs seem to prove this stetement.
